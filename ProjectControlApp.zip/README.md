# Project Control

A mobile-friendly starter PWA for managing projects, engineers and compliance paperwork.

## Included
- Dashboard
- Projects with engineer assignments
- Engineer register
- Paperwork register
- Document categories, versions and expiry/review dates
- Local file attachments
- Search
- Mobile-friendly interface
- Installable as a PWA

## Important
This first build stores data in the browser's local storage. It is ideal for testing the workflow, but it is **not yet a multi-user cloud system** and should not be treated as the final secure document repository.

## Run
Upload the contents of this folder to a static web host, or run locally with a simple web server.

For a production version, the next stage should add secure login, cloud database/storage, user permissions, electronic signatures, audit trail, automatic reminders and encrypted document storage.
